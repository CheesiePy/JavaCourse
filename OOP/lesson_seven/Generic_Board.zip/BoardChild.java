package OOP.lesson_seven;
public class BoardChild<T> extends Board<T> {

    public BoardChild(int size, T defaultValue) {
        super(size, defaultValue);
        //TODO Auto-generated constructor stub
    }
    
}
